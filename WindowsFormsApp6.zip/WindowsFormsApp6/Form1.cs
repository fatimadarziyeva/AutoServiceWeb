﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;        // **ƏLAVƏ OLUNUB** Fayl əməliyyatları üçün
using System.Text.Json;

// -----------------------------------------------------------
// BookItem sinfi (İTİN HİSSƏ ƏLAVƏ OLUNUB)
// -----------------------------------------------------------
public class BookItem
{
	public string Title { get; set; }
	public string Author { get; set; }
	public int Year { get; set; }

	public BookItem(string title, string author, int year)
	{
		Title = title;
		Author = author;
		Year = year;
	}
	public BookItem() { }
}

// -----------------------------------------------------------
// Sizin IBook interfeysi və Book sinfiniz burada davam edir...
// -----------------------------------------------------------
public interface IBook
{
	void AddBook(string title, string author, int year);
	void RemoveBook(string title);
	DataTable GetAllBooks();
	void SaveToFile(string path);
	void LoadFromFile(string path);
}
public class Book : IBook
{
	private List<BookItem> _books;
	// ... (Yuxarıdakı bütün Book sinif kodu olduğu kimi qalır)

	public Book()
	{
		_books = new List<BookItem>();
	}

	public void AddBook(string title, string author, int year)
	{
		if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author) || year <= 0)
		{
			throw new ArgumentException("Bütün sahələr doldurulmalıdır və il düzgün olmalıdır.");
		}
		var newBook = new BookItem(title, author, year);
		_books.Add(newBook);
	}

	public void RemoveBook(string title)
	{
		if (string.IsNullOrWhiteSpace(title))
		{
			throw new ArgumentException("Kitab başlığı boş ola bilməz.");
		}
		int removedCount = _books.RemoveAll(b => b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));

		if (removedCount == 0)
		{
			throw new InvalidOperationException($"Başlığı '{title}' olan kitab tapılmadı və silinmədi.");
		}
	}

	public DataTable GetAllBooks()
	{
		DataTable dt = new DataTable();
		// Sütun adları DataTable üçün Azərbaycan dilində olaraq dəyişdirildi.
		dt.Columns.Add("Başlıq", typeof(string));
		dt.Columns.Add("Müəllif", typeof(string));
		dt.Columns.Add("İl", typeof(int));

		foreach (var book in _books)
		{
			dt.Rows.Add(book.Title, book.Author, book.Year);
		}

		return dt;
	}

	public void SaveToFile(string path)
	{
		var options = new JsonSerializerOptions { WriteIndented = true };
		string jsonString = JsonSerializer.Serialize(_books, options);

		using (StreamWriter sw = new StreamWriter(path))
		{
			sw.Write(jsonString);
		}
	}

	public void LoadFromFile(string path)
	{
		if (!File.Exists(path))
		{
			throw new FileNotFoundException($"Fayl tapılmadı: {path}");
		}

		string jsonString;
		using (StreamReader sr = new StreamReader(path))
		{
			jsonString = sr.ReadToEnd();
		}

		var loadedBooks = JsonSerializer.Deserialize<List<BookItem>>(jsonString);

		if (loadedBooks != null)
		{
			_books = loadedBooks;
		}
		else
		{
			_books = new List<BookItem>();
		}
	}
}
// -----------------------------------------------------------
// WindowsFormsApp4 namespace-də Form1 sinfinə funksionallıq əlavə olunub
// -----------------------------------------------------------

namespace WindowsFormsApp4
{
	public partial class Form1 : Form
	{
		private IBook _bookManager;
		private const string DataFilePath = "books.txt"; // Kitab siyahısının saxlanılacağı fayl

		public Form1()
		{
			InitializeComponent();
			_bookManager = new Book();

			// Komponentlərin adları (Designer tərəfindən) düzgün təyin olunmalıdır! 
			// txtTitle, txtAuthor, txtYear, btnAdd, btnRemove, btnSave, btnLoad, dataGridView1

			// Tətbiq başlayarkən məlumatları yükləməyə cəhd edir
			LoadDataOnStartup();
			UpdateDataGridView();
		}

		// DataGridView-i yeniləyən metod
		private void UpdateDataGridView()
		{
			dataGridView1.DataSource = _bookManager.GetAllBooks();

			// Sütun başlıqlarını dəqiqləşdirir
			if (dataGridView1.Columns.Contains("Başlıq"))
				dataGridView1.Columns["Başlıq"].HeaderText = "Başlıq";
			if (dataGridView1.Columns.Contains("Müəllif"))
				dataGridView1.Columns["Müəllif"].HeaderText = "Müəllif";
			if (dataGridView1.Columns.Contains("İl"))
				dataGridView1.Columns["İl"].HeaderText = "Nəşr İli";
		}

		private void LoadDataOnStartup()
		{
			try
			{
				_bookManager.LoadFromFile(DataFilePath);
			}
			catch (FileNotFoundException)
			{
				// Fayl yoxdursa, problem yoxdur, boş siyahı ilə davam edirik.
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Başlanğıcda məlumat yüklənməsi xətası: {ex.Message}", "Yükləmə Xətası", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 'Əlavə et' düyməsi (btnAdd) üçün funksiya
		private void btnAdd_Click(object sender, EventArgs e)
		{
			try
			{
				if (!int.TryParse(txtYear.Text, out int year))
				{
					MessageBox.Show("Nəşr ili düzgün tam ədəd olmalıdır.", "Giriş Xətası", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}

				_bookManager.AddBook(txtTitle.Text.Trim(), txtAuthor.Text.Trim(), year);
				UpdateDataGridView();

				// Giriş sahələrini təmizlə
				txtTitle.Clear();
				txtAuthor.Clear();
				txtYear.Clear();
			}
			catch (ArgumentException ex)
			{
				MessageBox.Show(ex.Message, "Giriş Xətası", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Kitab əlavə edilərkən xəta: {ex.Message}", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 'Sil' düyməsi (btnRemove) üçün funksiya
		private void btnRemove_Click(object sender, EventArgs e)
		{
			try
			{
				string titleToRemove = txtTitle.Text.Trim();
				if (string.IsNullOrWhiteSpace(titleToRemove))
				{
					MessageBox.Show("Silmək üçün kitabın Başlığını daxil edin.", "Xəbərdarlıq", MessageBoxButtons.OK, MessageBoxIcon.Warning);
					return;
				}

				_bookManager.RemoveBook(titleToRemove);
				UpdateDataGridView();
				txtTitle.Clear();
				MessageBox.Show($"Başlığı '{titleToRemove}' olan kitab silindi.", "Uğurla Silindi", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (InvalidOperationException ex)
			{
				MessageBox.Show(ex.Message, "Silinmə Xətası", MessageBoxButtons.OK, MessageBoxIcon.Warning);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Kitab silinərkən xəta: {ex.Message}", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 'Yadda saxla' düyməsi (btnSave) üçün funksiya
		private void btnSave_Click(object sender, EventArgs e)
		{
			try
			{
				_bookManager.SaveToFile(DataFilePath);
				MessageBox.Show($"Məlumatlar '{DataFilePath}' faylına uğurla yadda saxlanıldı.", "Uğurlu Saxlanma", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Məlumatlar yadda saxlanılarkən xəta: {ex.Message}", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		// 'Yüklə' düyməsi (btnLoad) üçün funksiya
		private void btnLoad_Click(object sender, EventArgs e)
		{
			try
			{
				_bookManager.LoadFromFile(DataFilePath);
				UpdateDataGridView();
				MessageBox.Show($"Məlumatlar '{DataFilePath}' faylından uğurla yükləndi.", "Uğurlu Yüklənmə", MessageBoxButtons.OK, MessageBoxIcon.Information);
			}
			catch (FileNotFoundException ex)
			{
				MessageBox.Show(ex.Message, "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
			catch (Exception ex)
			{
				MessageBox.Show($"Məlumatlar yüklənərkən xəta: {ex.Message}", "Xəta", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}